/**

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DELAY_H
#define __DELAY_H

void delay_1us(u16 n_1us);
void delay_ms(u16 n_ms);

#endif /* __DELAY_H*/